#!/usr/bin/python3

import rclpy
from rclpy.node import Node
from ariac_msgs.msg import Order, AdvancedLogicalCameraImage, CompetitionState
from ariac_msgs.srv import MoveAGV, ChangeGripper, VacuumGripperControl
import PyKDL
from geometry_msgs.msg import Pose
import time
from example_interfaces.msg import String
from std_srvs.srv import Trigger
from competitor_interfaces.srv import PlacePartInTray, PickupTray, MovePartToAGV, MoveTrayToAGV, PlaceTrayOnAGV, PickupPart, RetractFromAGV
from rclpy.parameter import Parameter
from rclpy.callback_groups import MutuallyExclusiveCallbackGroup
from competitor_interfaces.msg import Robots as RobotsMsg
from competitor_interfaces.srv import (
    EnterToolChanger, ExitToolChanger
)
from rclpy.executors import MultiThreadedExecutor
from tf_transformations import quaternion_from_euler

data_dictionary = {}

class RWA4(Node):
    '''
    Simple class to create a ROS2 node

    Args:
        Node (class): ROS2 node class
    '''
    def __init__(self, node_name):
        """Class representing rwa4 node, this class is used to create subscribers, that subscribes to the topics:
            /ariac/orders
            /ariac/sensors/table1_camera/image
            /ariac/sensors/table2_camera/image
            /ariac/sensors/left_bins_camera/image
            /ariac/sensors/right_bins_camera/image

        Args:
            node_name (class): RWA4 inheriting (Node)
        """        
        super().__init__(node_name)
        self.declare_parameter('order_id', '100')
        self._order_id = self.get_parameter('order_id').get_parameter_value().string_value
        self.get_logger().info(f"Requested order : {self._order_id}")

        subsriber_group = MutuallyExclusiveCallbackGroup()
        timer_group = MutuallyExclusiveCallbackGroup()
        service_group = MutuallyExclusiveCallbackGroup()

#----------------------------------------------------------------  Subscribers ---------------------------------------------------------------------------------------

        self._subscriber1 = self.create_subscription(Order, '/ariac/orders', self._subscriber1_callback, 10, callback_group=subsriber_group)
        self._subscriber2 = self.create_subscription(AdvancedLogicalCameraImage, '/ariac/sensors/table1_camera/image',self._subscriber_callback_table1_camera, qos_profile=rclpy.qos.qos_profile_sensor_data, callback_group=subsriber_group)
        self._subscriber3 = self.create_subscription(AdvancedLogicalCameraImage, '/ariac/sensors/table2_camera/image',self._subscriber_callback_table2_camera, qos_profile=rclpy.qos.qos_profile_sensor_data, callback_group=subsriber_group)
        self._subscriber4 = self.create_subscription(AdvancedLogicalCameraImage, '/ariac/sensors/left_bins_camera/image',self._subscriber_callback_left_bins_camera, qos_profile=rclpy.qos.qos_profile_sensor_data, callback_group=subsriber_group)
        self._subscriber5 = self.create_subscription(AdvancedLogicalCameraImage, '/ariac/sensors/right_bins_camera/image',self._subscriber_callback_right_bins_camera, qos_profile=rclpy.qos.qos_profile_sensor_data, callback_group=subsriber_group)


        sim_time = Parameter(
            "use_sim_time",
            rclpy.Parameter.Type.BOOL,
            True
        )

        self.set_parameters([sim_time])

        # Flag to indicate if the kit has been completeds
        self._kit_completed = False
        self._competition_started = False
        self._competition_state = None

        # subscriber
        self.create_subscription(CompetitionState, '/ariac/competition_state',
                                 self._competition_state_cb, 1)
        
        self._robot_action_timer = self.create_timer(1, self._robot_action_timer_callback,
                                                     callback_group=timer_group)

#--------------------------------------------------------------- Service Clients ---------------------------------------------------------------------------------------------

        # 1. Service client for starting the competitions
        self._start_competition_client = self.create_client(Trigger, '/ariac/start_competition')

        # 2. Service client for moving the floor robot to the home position
        self._move_floor_robot_home_client = self.create_client(
            Trigger, '/competitor/floor_robot/go_home',
            callback_group=service_group)

        # 3. Service client for entering the gripper slot
        self._goto_tool_changer_client = self.create_client(
            EnterToolChanger, '/competitor/floor_robot/enter_tool_changer',
            callback_group=service_group)

        # 4. Service client for exiting the gripper slot
        self._retract_from_tool_changer_client = self.create_client(
            ExitToolChanger, '/competitor/floor_robot/exit_tool_changer',
            callback_group=service_group)

        # 5. Service client for picking up tray
        self._pickup_tray_client = self.create_client(
            PickupTray, '/competitor/floor_robot/pickup_tray',
            callback_group=service_group)

        # 6. Service client for moving tray to agv
        self._move_tray_to_agv_client = self.create_client(
            MoveTrayToAGV, '/competitor/floor_robot/move_tray_to_agv',
            callback_group=service_group)
        
        # 7. Service client for placing tray on agv
        self._place_tray_client = self.create_client(
            PlaceTrayOnAGV, '/competitor/floor_robot/place_tray_on_agv',
            callback_group=service_group)

        # 8. Service client for retracting from agv
        self._retract_from_agv_client = self.create_client(
            RetractFromAGV, '/competitor/floor_robot/retract_from_agv',
            callback_group=service_group)

        # 9. Service client for picking up part
        self._pickup_part_client = self.create_client(
            PickupPart, '/competitor/floor_robot/pickup_part',
            callback_group=service_group)

        # 10. Service client for moving part to agv
        self._move_part_to_agv_client = self.create_client(
            MovePartToAGV, '/competitor/floor_robot/move_part_to_agv',
            callback_group=service_group)

        # 11. Service client for placing part in tray
        self._place_part_in_tray_client = self.create_client(
            PlacePartInTray, '/competitor/floor_robot/place_part_in_tray',
            callback_group=service_group)

        # 12. Service client for locking tray on agv 1
        self._lock_agv1_client = self.create_client(
            Trigger, '/ariac/agv1_lock_tray',
            callback_group=service_group)

        # 13. Service client for locking tray on agv 2
        self._lock_agv2_client = self.create_client(
            Trigger, '/ariac/agv2_lock_tray',
            callback_group=service_group)

        # 14. Service client for locking tray on agv 3
        self._lock_agv3_client = self.create_client(
            Trigger, '/ariac/agv3_lock_tray',
            callback_group=service_group)

        # 15. Service client for locking tray on agv 4
        self._lock_agv4_client = self.create_client(
            Trigger, '/ariac/agv4_lock_tray',
            callback_group=service_group)

        # 16. Service client for moving agv 1
        self._move_agv1_to_warehouse_client = self.create_client(
            MoveAGV, '/ariac/move_agv1',
            callback_group=service_group)

        # 17. Service client for moving agv 2
        self._move_agv2_to_warehouse_client = self.create_client(
            MoveAGV, '/ariac/move_agv2',
            callback_group=service_group)
        
        # 18. Service client for moving agv 3
        self._move_agv3_to_warehouse_client = self.create_client(
            MoveAGV, '/ariac/move_agv3',
            callback_group=service_group)

        # 19. Service client for moving agv 4
        self._move_agv4_to_warehouse_client = self.create_client(
            MoveAGV, '/ariac/move_agv4',
            callback_group=service_group)

        # 20. Service client for changing gripper
        self._change_gripper_client = self.create_client(
            ChangeGripper, '/ariac/floor_robot_change_gripper',
            callback_group=service_group)

        # 21. Service client for enabling and disabling gripper
        self._set_floor_robot_gripper_state_client = self.create_client(
            VacuumGripperControl, '/ariac/floor_robot_enable_gripper',
            callback_group=service_group)


#------------------------------------------------------------- Subscriber Callback Functions -----------------------------------------------------------------------------------


    def _subscriber1_callback(self, message):
        """Callback function for the '/ariac/orders' topic subscriber.

        Args:
            message() = The messages received after subscribing to the topic

        Returns:
            None
        """         
        class Order():
            """Class to represent an order received to the /ariac/orders topic.
            """            
    
            def __init__(self, id, type, priority, agv_number, tray_id, destination, part1_color, part1_type, 
                         part1_quadrant, part2_color, part2_type, part2_quadrant):
                """Initializing an order object with the given attributes.

                Args:
                    id (int): The id of the order.
                    type (str): The type of order (e.g Kitting)
                    priority (bool): Priority of the order
                    agv_number (int): AGV number.
                    tray_id (int): Id of tray associated with the order
                    destination (int): The destination of order 
                    part1_color (int): Color of parts
                    part1_type (int): Type of parts
                    part1_quadrant (int): Quadrant at which the part is kept.
                    part2_color (int): Color of parts
                    part2_type (int): Type of parts
                    part2_quadrant (int): Quadrant at which the part is kept.
                """                
                self._id = id
                self._type = type
                self._priority = priority

                self._agv_number = agv_number
                self._tray_id = tray_id
                self._destination = destination

                self._part1_color = part1_color
                self._part1_type = part1_type
                self._part1_quadrant = part1_quadrant

                self._part2_color = part2_color
                self._part2_type = part2_type
                self._part2_quadrant = part2_quadrant

                if self._type == 0:
                    self._type = 'kitting'
                if self._type == 1:
                    self._type = 'assembly'
                if self._type == 2:
                    self._type = 'combined'

                if self._destination == 3:
                    self._destination = 'warehouse'
                
                if self._part1_color == 0:
                    self._part1_color = 'red'
                elif self._part1_color == 1:
                    self._part1_color = 'green'
                elif self._part1_color == 2:
                    self._part1_color = 'blue'
                elif self._part1_color == 3:
                    self._part1_color = 'orange'
                elif self._part1_color == 4:
                    self._part1_color = 'purple'

                if self._part2_color == 0:
                    self._part2_color = 'red'
                elif self._part2_color == 1:
                    self._part2_color = 'green'
                elif self._part2_color == 2:
                    self._part2_color = 'blue'
                elif self._part2_color == 3:
                    self._part2_color = 'orange'
                elif self._part2_color == 4:
                    self._part2_color = 'purple'               

                if self._part1_type == 10:
                    self._part1_type = 'battery'
                elif self._part1_type == 11:
                    self._part1_type = 'pump'                
                elif self._part1_type == 12:
                    self._part1_type = 'sensor'
                elif self._part1_type == 13:
                    self._part1_type = 'regulator'

                if self._part2_type == 10:
                    self._part2_type = 'battery'
                elif self._part2_type == 11:
                    self._part2_type = 'pump'                
                elif self._part2_type == 12:
                    self._part2_type = 'sensor'
                elif self._part2_type == 13:
                    self._part2_type = 'regulator'

            def __str__(self):
                """Overriding the inbuilt str function.

                Returns:
                    str: String containing the ID of the order. 
                """                

                text = f'''\n
order_id : '{self._id}'
type : '{self._type}'
priority : {self._priority}
kitting_task :
    agv_number : {self._agv_number}
    tray_id : {self._tray_id}
    destination : '{self._destination}'
    products:
        type : '{self._part1_type}'
        color : '{self._part1_color}'
        quadrant : {self._part1_quadrant}
        type : '{self._part2_type}'
        color : '{self._part2_color}'
        quadrant : {self._part2_quadrant}
                '''
                data_dictionary["order_id"] = self._id
                data_dictionary["type"] = self._type
                data_dictionary["agv_number"] = self._agv_number
                data_dictionary["tray_id"] = self._tray_id
                data_dictionary["destination"] = self._destination
                data_dictionary["part1_type"] = self._part1_type
                data_dictionary["part1_color"] = self._part1_color
                data_dictionary["part1_quadrant"] = self._part1_quadrant
                data_dictionary["part2_type"] = self._part2_type
                data_dictionary["part2_color"] = self._part2_color
                data_dictionary["part2_quadrant"] = self._part2_quadrant                
                return text


        order = Order(message.id, message.type, message.priority, message.kitting_task.agv_number,
                    message.kitting_task.tray_id, message.kitting_task.destination, message.kitting_task.parts[0].part.color,
                    message.kitting_task.parts[0].part.type, message.kitting_task.parts[0].quadrant, message.kitting_task.parts[1].part.color,
                    message.kitting_task.parts[1].part.type, message.kitting_task.parts[1].quadrant)
        


        if self._order_id == order._id:
            self.get_logger().info(str(order))



        self._iterations1 = True
        self._counter1 = 0
        self._iterations2 = True
        self._counter2 = 0
        self._iterations3 = True
        self._counter3 = 0
        self._iterations4 = True
        self._counter4 = 0
   

    def _subscriber_callback_table1_camera(self, message2):
        """Callback function for the /ariac/sensors/table1_camera/image topic subscriber.


        Args:
            message() = The messages received after subscribing to the topic

        Returns:
            None
        """          
        class AdvancedLogicalCameraImage():
            """Class to represent pose received from the /ariac/sensors/table1_camera/image topic. """  
        
            def _multiply_pose(self, pose1: Pose, pose2: Pose) -> Pose:
                '''
                Use KDL to multiply two poses together.
                Args:
                    pose1 (Pose): Pose of the first frame
                    pose2 (Pose): Pose of the second frame
                Returns:
                    Pose: Pose of the resulting frame
                '''

                orientation1 = pose1.orientation
                frame1 = PyKDL.Frame(
                    PyKDL.Rotation.Quaternion(orientation1.x, orientation1.y, orientation1.z, orientation1.w),
                    PyKDL.Vector(pose1.position.x, pose1.position.y, pose1.position.z))

                orientation2 = pose2.orientation
                frame2 = PyKDL.Frame(
                    PyKDL.Rotation.Quaternion(orientation2.x, orientation2.y, orientation2.z, orientation2.w),
                    PyKDL.Vector(pose2.position.x, pose2.position.y, pose2.position.z))

                frame3 = frame1 * frame2

                # return the resulting pose from frame3

                pose = Pose()
                pose.position.x = frame3.p.x()
                pose.position.y = frame3.p.y()
                pose.position.z = frame3.p.z()

                q = frame3.M.GetQuaternion()
                pose.orientation.x = q[0]
                pose.orientation.y = q[1]
                pose.orientation.z = q[2]
                pose.orientation.w = q[3]

                return pose

            def __init__(self, part_poses, id, tray_position_x, tray_position_y, tray_position_z,
                         tray_orientation_x, tray_orientation_y, tray_orientation_z, tray_orientation_w,
                         sensor_position_x, sensor_position_y, sensor_position_z,
                         sensor_orientation_x, sensor_orientation_y, sensor_orientation_z, sensor_orientation_w):
                """Initializing an order object with the given attributes.

                Args:
                    part_poses (list): List of the part poses.
                    id (int): Id of tray
                    tray_position_x (float): x coordinate of tray position
                    tray_position_y (float): y coordinate of tray position
                    tray_position_z (float): z coordinate of tray position
                    tray_orientation_x (float): x coordinate of tray orientation
                    tray_orientation_y (float): y coordinate of tray orientation
                    tray_orientation_z (float): z coordinate of tray orientation
                    tray_orientation_w (float): w coordinate of tray orientation
                    sensor_position_x (float): x coordinate of camera position
                    sensor_position_y (float): y coordinate of camera position
                    sensor_position_z (float): z coordinate of camera position
                    sensor_orientation_x (float): x coordinate of camera orientation
                    sensor_orientation_y (float): y coordinate of camera orientation
                    sensor_orientation_z (float): z coordinate of camera orientation
                    sensor_orientation_w (float): w coordinate of camera orientation
                """                
                self._part_poses = part_poses
                self._id = id

                self._tray_position_x = tray_position_x
                self._tray_position_y = tray_position_y
                self._tray_position_z = tray_position_z

                self._tray_orientation_x = tray_orientation_x
                self._tray_orientation_y = tray_orientation_y
                self._tray_orientation_z = tray_orientation_z
                self._tray_orientation_w = tray_orientation_w
           
                self._sensor_position_x = sensor_position_x
                self._sensor_position_y = sensor_position_y
                self._sensor_position_z = sensor_position_z

                self._sensor_orientation_x = sensor_orientation_x
                self._sensor_orientation_y = sensor_orientation_y
                self._sensor_orientation_z = sensor_orientation_z
                self._sensor_orientation_w = sensor_orientation_w

                self._pose1 = Pose()
                self._pose1.position.x = tray_position_x
                self._pose1.position.y = tray_position_y
                self._pose1.position.z = tray_position_z
                self._pose1.orientation.x = tray_orientation_x
                self._pose1.orientation.y = tray_orientation_y
                self._pose1.orientation.z = tray_orientation_z
                self._pose1.orientation.w = tray_orientation_w

                self._pose2 = Pose()
                self._pose2.position.x = sensor_position_x
                self._pose2.position.y = sensor_position_y
                self._pose2.position.z = sensor_position_z   
                self._pose2.orientation.x = sensor_orientation_x             
                self._pose2.orientation.y = sensor_orientation_y 
                self._pose2.orientation.z = sensor_orientation_z 
                self._pose2.orientation.w = sensor_orientation_w

                try:
                    if self._id == data_dictionary['tray_id']:
                        self._transform_pose_tray_1 = AdvancedLogicalCameraImage._multiply_pose(self, self._pose2, self._pose1)
                        data_dictionary["tray_position_x"] = self._transform_pose_tray_1.position.x
                        data_dictionary["tray_position_y"] = self._transform_pose_tray_1.position.y
                        data_dictionary["tray_position_z"] = self._transform_pose_tray_1.position.z
                        data_dictionary["tray_orientation_x"] = self._transform_pose_tray_1.orientation.x
                        data_dictionary["tray_orientation_y"] = self._transform_pose_tray_1.orientation.y
                        data_dictionary["tray_orientation_z"] = self._transform_pose_tray_1.orientation.z
                        data_dictionary["tray_orientation_w"] = self._transform_pose_tray_1.orientation.w
                        data_dictionary["tray_table"] = "kts1"
                except:
                    pass

            def __str__(self):
                """Overriding the inbuilt str function.

                Returns:
                    str: String containing the ID of the tray. 
                """
                text2 = f"\nTray: \n  -id: {self._id} \n  -pose:"
                return text2
        

        if self._iterations1:
            if message2.tray_poses != []:
                self._counter1 += 1
                if self._counter1 < 4:
                    object1 = AdvancedLogicalCameraImage(message2.part_poses, message2.tray_poses[0].id, message2.tray_poses[0].pose.position.x,
                                                        message2.tray_poses[0].pose.position.y, message2.tray_poses[0].pose.position.z,
                                                        message2.tray_poses[0].pose.orientation.x, message2.tray_poses[0].pose.orientation.y,
                                                        message2.tray_poses[0].pose.orientation.z, message2.tray_poses[0].pose.orientation.w,
                                                        message2.sensor_pose.position.x, message2.sensor_pose.position.y, message2.sensor_pose.position.z,
                                                        message2.sensor_pose.orientation.x, message2.sensor_pose.orientation.y,
                                                        message2.sensor_pose.orientation.z, message2.sensor_pose.orientation.w)
                    

                    world_pose = object1._multiply_pose(object1._pose2, object1._pose1)
                    # self.get_logger().info(f"{str(object1)}\n      -position: [{world_pose.position.x}, {world_pose.position.y}, {world_pose.position.z}]\n      -orientation: [{world_pose.orientation.x}, {world_pose.orientation.y}, {world_pose.orientation.z}, {world_pose.orientation.w}]")
                    # self.get_logger().info(str(object1))
                    self.iterations1 = False

    def _subscriber_callback_left_bins_camera(self, message3):
        """Callback function for the /ariac/sensors/left_bins_camera/image topic subscriber.

        Args:
            message() = The messages received after subscribing to the topic

        Returns:
            None
        """  
        class AdvancedLogicalCameraImage():
            """Class to represent pose received from the /ariac/sensors/left_bins_camera/image topic. """  
            
            def _multiply_pose(self, pose1: Pose, pose2: Pose) -> Pose:
                '''
                Use KDL to multiply two poses together.
                Args:
                    pose1 (Pose): Pose of the first frame
                    pose2 (Pose): Pose of the second frame
                Returns:
                    Pose: Pose of the resulting frame
                '''

                orientation1 = pose1.orientation
                frame1 = PyKDL.Frame(
                    PyKDL.Rotation.Quaternion(orientation1.x, orientation1.y, orientation1.z, orientation1.w),
                    PyKDL.Vector(pose1.position.x, pose1.position.y, pose1.position.z))

                orientation2 = pose2.orientation
                frame2 = PyKDL.Frame(
                    PyKDL.Rotation.Quaternion(orientation2.x, orientation2.y, orientation2.z, orientation2.w),
                    PyKDL.Vector(pose2.position.x, pose2.position.y, pose2.position.z))

                frame3 = frame1 * frame2

                # return the resulting pose from frame3

                pose = Pose()
                pose.position.x = frame3.p.x()
                pose.position.y = frame3.p.y()
                pose.position.z = frame3.p.z()

                q = frame3.M.GetQuaternion()
                pose.orientation.x = q[0]
                pose.orientation.y = q[1]
                pose.orientation.z = q[2]
                pose.orientation.w = q[3]

                return pose

            def __init__(self, part_color, part_type, part_position_x, part_position_y, part_position_z, part_orientation_x,
                         part_orientation_y, part_orientation_z, part_orientation_w, sensor_position_x, sensor_position_y, sensor_position_z,
                         sensor_orientation_x, sensor_orientation_y, sensor_orientation_z, sensor_orientation_w):
                """Initializing an order object with the given attributes.

                Args:
                    part_color (int): Part color
                    part_type (int): Part type
                    part_position_x (float): x coordinate of parts's position
                    part_position_y (float): y coordinate of parts's position
                    part_position_z (float): z coordinate of parts's position
                    part_orientation_x (float): x coordinate of parts's orientation
                    part_orientation_y (float): y coordinate of parts's orientation
                    part_orientation_z (float): z coordinate of parts's orientation
                    part_orientation_w (float): w coordinate of parts's orientation
                    sensor_position_x (float):  x coordinate of sensor's position
                    sensor_position_y (float):  y coordinate of sensor's position
                    sensor_position_z (float):  z coordinate of sensor's position
                    sensor_orientation_x (float): x coordinate of sensor's orientation
                    sensor_orientation_y (float): y coordinate of sensor's orientation
                    sensor_orientation_z (float): z coordinate of sensor's orientation
                    sensor_orientation_w (float): w coordinate of sensor's orientation
                """                  
                self._part_color = part_color
                if self._part_color == 0:
                    self._part_color = 'red'
                elif self._part_color == 1:
                    self._part_color = 'green'
                elif self._part_color == 2:
                    self._part_color = 'blue'
                elif self._part_color == 3:
                    self._part_color = 'orange'
                elif self._part_color == 4:
                    self._part_color = 'purple'

                self._part_type = part_type
                if self._part_type == 10:
                    self._part_type = 'battery'
                elif self._part_type == 11:
                    self._part_type = 'pump'
                elif self._part_type == 12:
                    self._part_type = 'sensor'
                elif self._part_type == 13:
                    self._part_type = 'regulator'

                self._part_position_x = part_position_x
                self._part_position_y = part_position_y
                self._part_position_z = part_position_z

                self._part_orientation_x = part_orientation_x
                self._part_orientation_y = part_orientation_y
                self._part_orientation_z = part_orientation_z
                self._part_orientation_w =part_orientation_w

                self._sensor_position_x = sensor_position_x
                self._sensor_position_y = sensor_position_y
                self._sensor_position_z = sensor_position_z

                self._sensor_orientation_x = sensor_orientation_x
                self._sensor_orientation_y = sensor_orientation_y
                self._sensor_orientation_z = sensor_orientation_z
                self._sensor_orientation_w = sensor_orientation_w

                self._pose1 = Pose()
                self._pose1.position.x = part_position_x
                self._pose1.position.y = part_position_y
                self._pose1.position.z = part_position_z
                self._pose1.orientation.x = part_orientation_x
                self._pose1.orientation.y = part_orientation_y
                self._pose1.orientation.z = part_orientation_z
                self._pose1.orientation.w = part_orientation_w

                self._pose2 = Pose()
                self._pose2.position.x = sensor_position_x
                self._pose2.position.y = sensor_position_y
                self._pose2.position.z = sensor_position_z   
                self._pose2.orientation.x = sensor_orientation_x             
                self._pose2.orientation.y = sensor_orientation_y 
                self._pose2.orientation.z = sensor_orientation_z 
                self._pose2.orientation.w = sensor_orientation_w


            def __str__(self):
                """Overriding the inbuilt str function.

                Returns:
                    str: String containing the Parts position and orientation. 
                """
                text2 = f"\nPart: {self._part_position_x}, {self._part_position_y}, {self._part_position_z}"
                return text2
        
        if self._iterations2:
                self._counter2 += 1
                if self._counter2 < 4:
                    self.iterations2 = True
                    object2 = AdvancedLogicalCameraImage(message3.part_poses[0].part.color, message3.part_poses[0].part.type, message3.part_poses[0].pose.position.x,
                                                        message3.part_poses[0].pose.position.y, message3.part_poses[0].pose.position.z, message3.part_poses[0].pose.orientation.x,
                                                        message3.part_poses[0].pose.orientation.y, message3.part_poses[0].pose.orientation.z, message3.part_poses[0].pose.orientation.w,
                                                        message3.sensor_pose.position.x, message3.sensor_pose.position.y, message3.sensor_pose.position.z, message3.sensor_pose.orientation.x,
                                                        message3.sensor_pose.orientation.y, message3.sensor_pose.orientation.z, message3.sensor_pose.orientation.w)

                    object2_4 = AdvancedLogicalCameraImage(message3.part_poses[3].part.color, message3.part_poses[3].part.type, message3.part_poses[3].pose.position.x,
                                                        message3.part_poses[3].pose.position.y, message3.part_poses[3].pose.position.z, message3.part_poses[3].pose.orientation.x,
                                                        message3.part_poses[3].pose.orientation.y, message3.part_poses[3].pose.orientation.z, message3.part_poses[3].pose.orientation.w,
                                                        message3.sensor_pose.position.x, message3.sensor_pose.position.y, message3.sensor_pose.position.z, message3.sensor_pose.orientation.x,
                                                        message3.sensor_pose.orientation.y, message3.sensor_pose.orientation.z, message3.sensor_pose.orientation.w)
                    

                    object2_2 = AdvancedLogicalCameraImage(message3.part_poses[1].part.color, message3.part_poses[1].part.type, message3.part_poses[1].pose.position.x,
                                                        message3.part_poses[1].pose.position.y, message3.part_poses[1].pose.position.z, message3.part_poses[1].pose.orientation.x,
                                                        message3.part_poses[1].pose.orientation.y, message3.part_poses[1].pose.orientation.z, message3.part_poses[1].pose.orientation.w,
                                                        message3.sensor_pose.position.x, message3.sensor_pose.position.y, message3.sensor_pose.position.z, message3.sensor_pose.orientation.x,
                                                        message3.sensor_pose.orientation.y, message3.sensor_pose.orientation.z, message3.sensor_pose.orientation.w)
                    
                    object2_3 = AdvancedLogicalCameraImage(message3.part_poses[2].part.color, message3.part_poses[2].part.type, message3.part_poses[2].pose.position.x,
                                                        message3.part_poses[2].pose.position.y, message3.part_poses[2].pose.position.z, message3.part_poses[2].pose.orientation.x,
                                                        message3.part_poses[2].pose.orientation.y, message3.part_poses[2].pose.orientation.z, message3.part_poses[2].pose.orientation.w,
                                                        message3.sensor_pose.position.x, message3.sensor_pose.position.y, message3.sensor_pose.position.z, message3.sensor_pose.orientation.x,
                                                        message3.sensor_pose.orientation.y, message3.sensor_pose.orientation.z, message3.sensor_pose.orientation.w)                    


                    if message3.part_poses[0].part.color == 0:
                        color = 'Red'
                    elif message3.part_poses[0].part.color == 1:
                        color = 'Green'
                    elif message3.part_poses[0].part.color == 2:
                        color = 'Blue' 
                    elif message3.part_poses[0].part.color == 3:
                        color = 'Orange'
                    elif message3.part_poses[0].part.color == 4:
                        color = 'Purple'

                    if message3.part_poses[0].part.type == 10:
                        component = 'Battery'    
                    if message3.part_poses[0].part.type == 11:
                        component = 'Pump'
                    if message3.part_poses[0].part.type == 12:
                        component = 'Sensor'
                    if message3.part_poses[0].part.type == 13:
                        component = 'Regulator'


                    object2_done = False
                    object2_2_done = False
                    object2_3_done = False
                    object2_4_done = False


                    try:
                        if object2_done == False:
                            if object2._part_type == data_dictionary["part1_type"]:
                                object2_done = True
                                world_pose2 = object2._multiply_pose(object2._pose2, object2._pose1)
                                data_dictionary['part1_position_x'] = world_pose2.position.x
                                data_dictionary['part1_position_y'] = world_pose2.position.y
                                data_dictionary['part1_position_z'] = world_pose2.position.z
                                data_dictionary['part1_orientation_x'] = world_pose2.orientation.x
                                data_dictionary['part1_orientation_y'] = world_pose2.orientation.y
                                data_dictionary['part1_orientation_z'] = world_pose2.orientation.z
                                data_dictionary['part1_orientation_w'] = world_pose2.orientation.w
                                data_dictionary['part1_bins'] = 'left_bins'
                    except:
                        pass

                    try:
                        if object2_done == False:
                            if object2._part_type == data_dictionary["part2_type"]:
                                object2_done = True
                                world_pose2 = object2._multiply_pose(object2._pose2, object2._pose1)
                                data_dictionary['part2_position_x'] = world_pose2.position.x
                                data_dictionary['part2_position_y'] = world_pose2.position.y
                                data_dictionary['part2_position_z'] = world_pose2.position.z
                                data_dictionary['part2_orientation_x'] = world_pose2.orientation.x
                                data_dictionary['part2_orientation_y'] = world_pose2.orientation.y
                                data_dictionary['part2_orientation_z'] = world_pose2.orientation.z
                                data_dictionary['part2_orientation_w'] = world_pose2.orientation.w
                                data_dictionary['part2_bins'] = 'left_bins'
                    except:
                        pass

                    try:
                        if object2_2_done == False:
                            if object2_2._part_type == data_dictionary["part1_type"]:
                                object2_2_done = True
                                world_pose2_2 = object2._multiply_pose(object2_2._pose2, object2_2._pose1)
                                data_dictionary['part1_position_x'] = world_pose2_2.position.x
                                data_dictionary['part1_position_y'] = world_pose2_2.position.y
                                data_dictionary['part1_position_z'] = world_pose2_2.position.z
                                data_dictionary['part1_orientation_x'] = world_pose2_2.orientation.x
                                data_dictionary['part1_orientation_y'] = world_pose2_2.orientation.y
                                data_dictionary['part1_orientation_z'] = world_pose2_2.orientation.z
                                data_dictionary['part1_orientation_w'] = world_pose2_2.orientation.w
                                data_dictionary['part1_bins'] = 'left_bins'
                    except:
                        pass

                    try:
                        if object2_2_done == False:
                            if object2_2._part_type == data_dictionary["part2_type"]:
                                object2_2_done = True
                                world_pose2_2 = object2._multiply_pose(object2_2._pose2, object2_2._pose1)
                                data_dictionary['part2_position_x'] = world_pose2_2.position.x
                                data_dictionary['part2_position_y'] = world_pose2_2.position.y
                                data_dictionary['part2_position_z'] = world_pose2_2.position.z
                                data_dictionary['part2_orientation_x'] = world_pose2_2.orientation.x
                                data_dictionary['part2_orientation_y'] = world_pose2_2.orientation.y
                                data_dictionary['part2_orientation_z'] = world_pose2_2.orientation.z
                                data_dictionary['part2_orientation_w'] = world_pose2_2.orientation.w
                                data_dictionary['part2_bins'] = 'left_bins'
                    except:
                        pass

                    try:
                        if object2_3_done == False:
                            if object2_3._part_type == data_dictionary["part1_type"]:
                                object2_3_done = True
                                world_pose2_3 = object2_3._multiply_pose(object2_3._pose2, object2_3._pose1)
                                data_dictionary['part1_position_x'] = world_pose2_3.position.x
                                data_dictionary['part1_position_y'] = world_pose2_3.position.y
                                data_dictionary['part1_position_z'] = world_pose2_3.position.z
                                data_dictionary['part1_orientation_x'] = world_pose2_3.orientation.x
                                data_dictionary['part1_orientation_y'] = world_pose2_3.orientation.y
                                data_dictionary['part1_orientation_z'] = world_pose2_3.orientation.z
                                data_dictionary['part1_orientation_w'] = world_pose2_3.orientation.w
                                data_dictionary['part1_bins'] = 'left_bins'
                    except:
                        pass

                    try:
                        if object2_3_done == False:
                            if object2_3._part_type == data_dictionary["part2_type"]:
                                object2_3_done = True
                                world_pose2_3 = object2_3._multiply_pose(object2_3._pose2, object2_3._pose1)
                                data_dictionary['part2_position_x'] = world_pose2_3.position.x
                                data_dictionary['part2_position_y'] = world_pose2_3.position.y
                                data_dictionary['part2_position_z'] = world_pose2_3.position.z
                                data_dictionary['part2_orientation_x'] = world_pose2_3.orientation.x
                                data_dictionary['part2_orientation_y'] = world_pose2_3.orientation.y
                                data_dictionary['part2_orientation_z'] = world_pose2_3.orientation.z
                                data_dictionary['part2_orientation_w'] = world_pose2_3.orientation.w
                                data_dictionary['part2_bins'] = 'left_bins'
                    except:
                        pass

                    try:
                        if object2_4_done == False:
                            if object2_4._part_type == data_dictionary["part2_type"]:
                                object2_4_done = True
                                world_pose2_4 = object2_4._multiply_pose(object2_4._pose2, object2_4._pose1)
                                data_dictionary['part2_position_x'] = world_pose2_4.position.x
                                data_dictionary['part2_position_y'] = world_pose2_4.position.y
                                data_dictionary['part2_position_z'] = world_pose2_4.position.z
                                data_dictionary['part2_orientation_x'] = world_pose2_4.orientation.x
                                data_dictionary['part2_orientation_y'] = world_pose2_4.orientation.y
                                data_dictionary['part2_orientation_z'] = world_pose2_4.orientation.z
                                data_dictionary['part2_orientation_w'] = world_pose2_4.orientation.w
                                data_dictionary['part2_bins'] = 'left_bins'
                    except:
                        pass
                
                    try:
                        if object2_4_done == False:
                            if object2_4._part_type == data_dictionary["part1_type"]:
                                object2_4_done = True
                                world_pose2_4 = object2_4._multiply_pose(object2_4._pose2, object2_4._pose1)
                                data_dictionary['part1_position_x'] = world_pose2_4.position.x
                                data_dictionary['part1_position_y'] = world_pose2_4.position.y
                                data_dictionary['part1_position_z'] = world_pose2_4.position.z
                                data_dictionary['part1_orientation_x'] = world_pose2_4.orientation.x
                                data_dictionary['part1_orientation_y'] = world_pose2_4.orientation.y
                                data_dictionary['part1_orientation_z'] = world_pose2_4.orientation.z
                                data_dictionary['part1_orientation_w'] = world_pose2_4.orientation.w
                                data_dictionary['part1_bins'] = 'left_bins'
                    except:
                        pass


                    # self.get_logger().info(f"{str(object2)}\n  -{color} {component}\n    -pose:\n      -position: [{world_pose2.position.x}, {world_pose2.position.y}, {world_pose2.position.z}]\n      -orientation: [{world_pose.orientation.x}, {world_pose.orientation.y}, {world_pose.orientation.z}, {world_pose.orientation.w}]")
                    # self.get_logger().info(str(object2))
                else:
                    self._iterations2 = False



    def _subscriber_callback_right_bins_camera(self, message4):
        """Callback function for the /ariac/sensors/right_bins_camera/imagetopic subscriber.


        Args:
            message() = The messages received after subscribing to the topic

        Returns:
            None
        """  
        class AdvancedLogicalCameraImage():
            
            def _multiply_pose(self, pose1: Pose, pose2: Pose) -> Pose:
                '''
                Use KDL to multiply two poses together.
                Args:
                    pose1 (Pose): Pose of the first frame
                    pose2 (Pose): Pose of the second frame
                Returns:
                    Pose: Pose of the resulting frame
                '''

                orientation1 = pose1.orientation
                frame1 = PyKDL.Frame(
                    PyKDL.Rotation.Quaternion(orientation1.x, orientation1.y, orientation1.z, orientation1.w),
                    PyKDL.Vector(pose1.position.x, pose1.position.y, pose1.position.z))

                orientation2 = pose2.orientation
                frame2 = PyKDL.Frame(
                    PyKDL.Rotation.Quaternion(orientation2.x, orientation2.y, orientation2.z, orientation2.w),
                    PyKDL.Vector(pose2.position.x, pose2.position.y, pose2.position.z))

                frame3 = frame1 * frame2

                # return the resulting pose from frame3

                pose = Pose()
                pose.position.x = frame3.p.x()
                pose.position.y = frame3.p.y()
                pose.position.z = frame3.p.z()

                q = frame3.M.GetQuaternion()
                pose.orientation.x = q[0]
                pose.orientation.y = q[1]
                pose.orientation.z = q[2]
                pose.orientation.w = q[3]

                return pose

            def __init__(self, part_color, part_type, part_position_x, part_position_y, part_position_z, part_orientation_x,
                         part_orientation_y, part_orientation_z, part_orientation_w, sensor_position_x, sensor_position_y, sensor_position_z,
                         sensor_orientation_x, sensor_orientation_y, sensor_orientation_z, sensor_orientation_w):
                """Initializing an order object with the given attributes.

                Args:
                    part_color (int): Part color
                    part_type (int): Part type
                    part_position_x (float): x coordinate of parts's position
                    part_position_y (float): y coordinate of parts's position
                    part_position_z (float): z coordinate of parts's position
                    part_orientation_x (float): x coordinate of parts's orientation
                    part_orientation_y (float): y coordinate of parts's orientation
                    part_orientation_z (float): z coordinate of parts's orientation
                    part_orientation_w (float): w coordinate of parts's orientation
                    sensor_position_x (float):  x coordinate of sensor's position
                    sensor_position_y (float):  y coordinate of sensor's position
                    sensor_position_z (float):  z coordinate of sensor's position
                    sensor_orientation_x (float): x coordinate of sensor's orientation
                    sensor_orientation_y (float): y coordinate of sensor's orientation
                    sensor_orientation_z (float): z coordinate of sensor's orientation
                    sensor_orientation_w (float): w coordinate of sensor's orientation
                """        
                self._part_color = part_color
                if self._part_color == 0:
                    self._part_color = 'red'
                elif self._part_color == 1:
                    self._part_color = 'green'
                elif self._part_color == 2:
                    self._part_color = 'blue'
                elif self._part_color == 3:
                    self._part_color = 'orange'
                elif self._part_color == 4:
                    self._part_color = 'purple'

                self._part_type = part_type
                if self._part_type == 10:
                    self._part_type = 'battery'
                elif self._part_type == 11:
                    self._part_type = 'pump'
                elif self._part_type == 12:
                    self._part_type = 'sensor'
                elif self._part_type == 13:
                    self._part_type = 'regulator'

                self._part_position_x = part_position_x
                self._part_position_y = part_position_y
                self._part_position_z = part_position_z

                self._part_orientation_x = part_orientation_x
                self._part_orientation_y = part_orientation_y
                self._part_orientation_z = part_orientation_z
                self._part_orientation_w =part_orientation_w

                self._sensor_position_x = sensor_position_x
                self._sensor_position_y = sensor_position_y
                self._sensor_position_z = sensor_position_z

                self._sensor_orientation_x = sensor_orientation_x
                self._sensor_orientation_y = sensor_orientation_y
                self._sensor_orientation_z = sensor_orientation_z
                self._sensor_orientation_w = sensor_orientation_w

                self._pose1 = Pose()
                self._pose1.position.x = part_position_x
                self._pose1.position.y = part_position_y
                self._pose1.position.z = part_position_z
                self._pose1.orientation.x = part_orientation_x
                self._pose1.orientation.y = part_orientation_y
                self._pose1.orientation.z = part_orientation_z
                self._pose1.orientation.w = part_orientation_w

                self._pose2 = Pose()
                self._pose2.position.x = sensor_position_x
                self._pose2.position.y = sensor_position_y
                self._pose2.position.z = sensor_position_z   
                self._pose2.orientation.x = sensor_orientation_x             
                self._pose2.orientation.y = sensor_orientation_y 
                self._pose2.orientation.z = sensor_orientation_z 
                self._pose2.orientation.w = sensor_orientation_w

            def __str__(self):
                """Overriding the inbuilt str function.

                Returns:
                    str: String containing the Parts position and orientation. 
                """
                text2 = f"\nPart: {self._part_type}, {self._part_color}"
                return text2
        
        if self._iterations3:
                self._counter3 += 1
                if self._counter3 < 4:
                    object3 = AdvancedLogicalCameraImage(message4.part_poses[0].part.color, message4.part_poses[0].part.type, message4.part_poses[0].pose.position.x,
                                                        message4.part_poses[0].pose.position.y, message4.part_poses[0].pose.position.z, message4.part_poses[0].pose.orientation.x,
                                                        message4.part_poses[0].pose.orientation.y, message4.part_poses[0].pose.orientation.z, message4.part_poses[0].pose.orientation.w,
                                                        message4.sensor_pose.position.x, message4.sensor_pose.position.y, message4.sensor_pose.position.z, message4.sensor_pose.orientation.x,
                                                        message4.sensor_pose.orientation.y, message4.sensor_pose.orientation.z, message4.sensor_pose.orientation.w)

                    object3_3 = AdvancedLogicalCameraImage(message4.part_poses[3].part.color, message4.part_poses[3].part.type, message4.part_poses[3].pose.position.x,
                                                        message4.part_poses[3].pose.position.y, message4.part_poses[3].pose.position.z, message4.part_poses[3].pose.orientation.x,
                                                        message4.part_poses[3].pose.orientation.y, message4.part_poses[3].pose.orientation.z, message4.part_poses[3].pose.orientation.w,
                                                        message4.sensor_pose.position.x, message4.sensor_pose.position.y, message4.sensor_pose.position.z, message4.sensor_pose.orientation.x,
                                                        message4.sensor_pose.orientation.y, message4.sensor_pose.orientation.z, message4.sensor_pose.orientation.w)  

                    object3_2 = AdvancedLogicalCameraImage(message4.part_poses[2].part.color, message4.part_poses[2].part.type, message4.part_poses[2].pose.position.x,
                                                        message4.part_poses[2].pose.position.y, message4.part_poses[2].pose.position.z, message4.part_poses[2].pose.orientation.x,
                                                        message4.part_poses[2].pose.orientation.y, message4.part_poses[2].pose.orientation.z, message4.part_poses[2].pose.orientation.w,
                                                        message4.sensor_pose.position.x, message4.sensor_pose.position.y, message4.sensor_pose.position.z, message4.sensor_pose.orientation.x,
                                                        message4.sensor_pose.orientation.y, message4.sensor_pose.orientation.z, message4.sensor_pose.orientation.w) 

                    object3_4 = AdvancedLogicalCameraImage(message4.part_poses[1].part.color, message4.part_poses[1].part.type, message4.part_poses[1].pose.position.x,
                                                        message4.part_poses[1].pose.position.y, message4.part_poses[1].pose.position.z, message4.part_poses[1].pose.orientation.x,
                                                        message4.part_poses[1].pose.orientation.y, message4.part_poses[1].pose.orientation.z, message4.part_poses[1].pose.orientation.w,
                                                        message4.sensor_pose.position.x, message4.sensor_pose.position.y, message4.sensor_pose.position.z, message4.sensor_pose.orientation.x,
                                                        message4.sensor_pose.orientation.y, message4.sensor_pose.orientation.z, message4.sensor_pose.orientation.w)              


                    if message4.part_poses[0].part.color == 0:
                        color = 'Red'
                    elif message4.part_poses[0].part.color == 1:
                        color = 'Green'
                    elif message4.part_poses[0].part.color == 2:
                        color = 'Blue' 
                    elif message4.part_poses[0].part.color == 3:
                        color = 'Orange'
                    elif message4.part_poses[0].part.color == 4:
                        color = 'Purple'

                    if message4.part_poses[0].part.type == 10:
                        component = 'Battery'    
                    if message4.part_poses[0].part.type == 11:
                        component = 'Pump'
                    if message4.part_poses[0].part.type == 12:
                        component = 'Sensor'
                    if message4.part_poses[0].part.type == 13:
                        component = 'Regulator'

                    try:
                        if object3._part_type == data_dictionary["part1_type"]:
                            world_pose3 = object3._multiply_pose(object3._pose2, object3._pose1)
                            data_dictionary['part1_position_x'] = world_pose3.position.x
                            data_dictionary['part1_position_y'] = world_pose3.position.y
                            data_dictionary['part1_position_z'] = world_pose3.position.z
                            data_dictionary['part1_orientation_x'] = world_pose3.orientation.x
                            data_dictionary['part1_orientation_y'] = world_pose3.orientation.y
                            data_dictionary['part1_orientation_z'] = world_pose3.orientation.z
                            data_dictionary['part1_orientation_w'] = world_pose3.orientation.w
                            data_dictionary['part1_bins'] = 'right_bins'
                    except:
                        pass

                    try:
                        if object3_3._part_type == data_dictionary["part1_type"]:
                            world_pose3_3 = object3._multiply_pose(object3_3._pose2, object3_3._pose1)
                            data_dictionary['part1_position_x'] = world_pose3_3.position.x
                            data_dictionary['part1_position_y'] = world_pose3_3.position.y
                            data_dictionary['part1_position_z'] = world_pose3_3.position.z
                            data_dictionary['part1_orientation_x'] = world_pose3_3.orientation.x
                            data_dictionary['part1_orientation_y'] = world_pose3_3.orientation.y
                            data_dictionary['part1_orientation_z'] = world_pose3_3.orientation.z
                            data_dictionary['part1_orientation_w'] = world_pose3_3.orientation.w
                            data_dictionary['part1_bins'] = 'right_bins'
                    except:
                        pass

                    try:
                        if object3._part_type == data_dictionary["part2_type"]:
                            world_pose3 = object3._multiply_pose(object3._pose2, object3._pose1)
                            data_dictionary['part2_position_x'] = world_pose3.position.x
                            data_dictionary['part2_position_y'] = world_pose3.position.y
                            data_dictionary['part2_position_z'] = world_pose3.position.z
                            data_dictionary['part2_orientation_x'] = world_pose3.orientation.x
                            data_dictionary['part2_orientation_y'] = world_pose3.orientation.y
                            data_dictionary['part2_orientation_z'] = world_pose3.orientation.z
                            data_dictionary['part2_orientation_w'] = world_pose3.orientation.w
                            data_dictionary['part2_bins'] = 'right_bins'
                    except:
                        pass

                    try:
                        if object3_3._part_type == data_dictionary["part2_type"]:
                            world_pose3_3 = object3._multiply_pose(object3_3._pose2, object3_3._pose1)
                            data_dictionary['part2_position_x'] = world_pose3_3.position.x
                            data_dictionary['part2_position_y'] = world_pose3_3.position.y
                            data_dictionary['part2_position_z'] = world_pose3_3.position.z
                            data_dictionary['part2_orientation_x'] = world_pose3_3.orientation.x
                            data_dictionary['part2_orientation_y'] = world_pose3_3.orientation.y
                            data_dictionary['part2_orientation_z'] = world_pose3_3.orientation.z
                            data_dictionary['part2_orientation_w'] = world_pose3_3.orientation.w
                            data_dictionary['part2_bins'] = 'right_bins'
                    except:
                        pass

                    try:
                        if object3_2._part_type == data_dictionary["part1_type"]:
                            world_pose3_2 = object3_2._multiply_pose(object3_2._pose2, object3_2._pose1)
                            data_dictionary['part1_position_x'] = world_pose3_2.position.x
                            data_dictionary['part1_position_y'] = world_pose3_2.position.y
                            data_dictionary['part1_position_z'] = world_pose3_2.position.z
                            data_dictionary['part1_orientation_x'] = world_pose3_2.orientation.x
                            data_dictionary['part1_orientation_y'] = world_pose3_2.orientation.y
                            data_dictionary['part1_orientation_z'] = world_pose3_2.orientation.z
                            data_dictionary['part1_orientation_w'] = world_pose3_2.orientation.w
                            data_dictionary['part1_bins'] = 'right_bins'
                    except:
                        pass

                    try:
                        if object3_4._part_type == data_dictionary["part1_type"]:
                            world_pose3_4 = object3_4._multiply_pose(object3_4._pose2, object3_4._pose1)
                            data_dictionary['part1_position_x'] = world_pose3_4.position.x
                            data_dictionary['part1_position_y'] = world_pose3_4.position.y
                            data_dictionary['part1_position_z'] = world_pose3_4.position.z
                            data_dictionary['part1_orientation_x'] = world_pose3_4.orientation.x
                            data_dictionary['part1_orientation_y'] = world_pose3_4.orientation.y
                            data_dictionary['part1_orientation_z'] = world_pose3_4.orientation.z
                            data_dictionary['part1_orientation_w'] = world_pose3_4.orientation.w
                            data_dictionary['part1_bins'] = 'right_bins'
                    except:
                        pass

                    try:
                        if object3_2._part_type == data_dictionary["part2_type"]:
                            world_pose3_2 = object3_2._multiply_pose(object3_2._pose2, object3_2._pose1)
                            data_dictionary['part2_position_x'] = world_pose3_2.position.x
                            data_dictionary['part2_position_y'] = world_pose3_2.position.y
                            data_dictionary['part2_position_z'] = world_pose3_2.position.z
                            data_dictionary['part2_orientation_x'] = world_pose3_2.orientation.x
                            data_dictionary['part2_orientation_y'] = world_pose3_2.orientation.y
                            data_dictionary['part2_orientation_z'] = world_pose3_2.orientation.z
                            data_dictionary['part2_orientation_w'] = world_pose3_2.orientation.w
                            data_dictionary['part2_bins'] = 'right_bins'
                    except:
                        pass

                    try:
                        if object3_4._part_type == data_dictionary["part1_type"]:
                            world_pose3_4 = object3_4._multiply_pose(object3_4._pose2, object3_4._pose1)
                            data_dictionary['part2_position_x'] = world_pose3_4.position.x
                            data_dictionary['part2_position_y'] = world_pose3_4.position.y
                            data_dictionary['part2_position_z'] = world_pose3_4.position.z
                            data_dictionary['part2_orientation_x'] = world_pose3_4.orientation.x
                            data_dictionary['part2_orientation_y'] = world_pose3_4.orientation.y
                            data_dictionary['part2_orientation_z'] = world_pose3_4.orientation.z
                            data_dictionary['part2_orientation_w'] = world_pose3_4.orientation.w
                            data_dictionary['part2_bins'] = 'right_bins'
                    except:
                        pass

                    world_pose = object3._multiply_pose(object3._pose2, object3._pose1)
                    # self.get_logger().info(f"{str(object3)}\n  -{color} {component}\n    -pose:\n      -position: [{world_pose.position.x}, {world_pose.position.y}, {world_pose.position.z}]\n      -orientation: [{world_pose.orientation.x}, {world_pose.orientation.y}, {world_pose.orientation.z}, {world_pose.orientation.w}]")
                    # self.get_logger().info(str(object3))
                    self.iterations3 = False


    def _subscriber_callback_table2_camera(self, message2):
        """Callback function for the /ariac/sensors/table2_camera/image topic subscriber.


        Args:
            message() = The messages received after subscribing to the topic

        Returns:
            None
        """  
        class AdvancedLogicalCameraImage():
            def _multiply_pose(self, pose1: Pose, pose2: Pose) -> Pose:
                '''
                Use KDL to multiply two poses together.
                Args:
                    pose1 (Pose): Pose of the first frame
                    pose2 (Pose): Pose of the second frame
                Returns:
                    Pose: Pose of the resulting frame
                '''

                orientation1 = pose1.orientation
                frame1 = PyKDL.Frame(
                    PyKDL.Rotation.Quaternion(orientation1.x, orientation1.y, orientation1.z, orientation1.w),
                    PyKDL.Vector(pose1.position.x, pose1.position.y, pose1.position.z))

                orientation2 = pose2.orientation
                frame2 = PyKDL.Frame(
                    PyKDL.Rotation.Quaternion(orientation2.x, orientation2.y, orientation2.z, orientation2.w),
                    PyKDL.Vector(pose2.position.x, pose2.position.y, pose2.position.z))

                frame3 = frame1 * frame2

                # return the r  esulting pose from frame3

                pose = Pose()
                pose.position.x = frame3.p.x()
                pose.position.y = frame3.p.y()
                pose.position.z = frame3.p.z()

                q = frame3.M.GetQuaternion()
                pose.orientation.x = q[0]
                pose.orientation.y = q[1]
                pose.orientation.z = q[2]
                pose.orientation.w = q[3]

                return pose

            def __init__(self, part_poses, id, tray_position_x, tray_position_y, tray_position_z,
                         tray_orientation_x, tray_orientation_y, tray_orientation_z, tray_orientation_w,
                         sensor_position_x, sensor_position_y, sensor_position_z,
                         sensor_orientation_x, sensor_orientation_y, sensor_orientation_z, sensor_orientation_w):
                """Initializing an order object with the given attributes.

                Args:
                    part_poses (list): List of the part poses.
                    id (int): Id of tray
                    tray_position_x (float): x coordinate of tray position
                    tray_position_y (float): y coordinate of tray position
                    tray_position_z (float): z coordinate of tray position
                    tray_orientation_x (float): x coordinate of tray orientation
                    tray_orientation_y (float): y coordinate of tray orientation
                    tray_orientation_z (float): z coordinate of tray orientation
                    tray_orientation_w (float): w coordinate of tray orientation
                    sensor_position_x (float): x coordinate of camera position
                    sensor_position_y (float): y coordinate of camera position
                    sensor_position_z (float): z coordinate of camera position
                    sensor_orientation_x (float): x coordinate of camera orientation
                    sensor_orientation_y (float): y coordinate of camera orientation
                    sensor_orientation_z (float): z coordinate of camera orientation
                    sensor_orientation_w (float): w coordinate of camera orientation
                """     
                self._part_poses = part_poses
                self._id = id

                self._tray_position_x = tray_position_x
                self._tray_position_y = tray_position_y
                self._tray_position_z = tray_position_z

                self._tray_orientation_x = tray_orientation_x
                self._tray_orientation_y = tray_orientation_y
                self._tray_orientation_z = tray_orientation_z
                self._tray_orientation_w = tray_orientation_w
           
                self._sensor_position_x = sensor_position_x
                self._sensor_position_y = sensor_position_y
                self._sensor_position_z = sensor_position_z

                self._sensor_orientation_x = sensor_orientation_x
                self._sensor_orientation_y = sensor_orientation_y
                self._sensor_orientation_z = sensor_orientation_z
                self._sensor_orientation_w = sensor_orientation_w

                self._pose1 = Pose()
                self._pose1.position.x = tray_position_x
                self._pose1.position.y = tray_position_y
                self._pose1.position.z = tray_position_z
                self._pose1.orientation.x = tray_orientation_x
                self._pose1.orientation.y = tray_orientation_y
                self._pose1.orientation.z = tray_orientation_z
                self._pose1.orientation.w = tray_orientation_w

                self._pose2 = Pose()
                self._pose2.position.x = sensor_position_x
                self._pose2.position.y = sensor_position_y
                self._pose2.position.z = sensor_position_z   
                self._pose2.orientation.x = sensor_orientation_x             
                self._pose2.orientation.y = sensor_orientation_y 
                self._pose2.orientation.z = sensor_orientation_z 
                self._pose2.orientation.w = sensor_orientation_w

                try:
                    if self._id == data_dictionary['tray_id']:
                        self._transform_pose_tray_1 = AdvancedLogicalCameraImage._multiply_pose(self, self._pose2, self._pose1)
                        data_dictionary["tray_position_x"] = self._transform_pose_tray_1.position.x
                        data_dictionary["tray_position_y"] = self._transform_pose_tray_1.position.y
                        data_dictionary["tray_position_z"] = self._transform_pose_tray_1.position.z
                        data_dictionary["tray_orientation_x"] = self._transform_pose_tray_1.orientation.x
                        data_dictionary["tray_orientation_y"] = self._transform_pose_tray_1.orientation.y
                        data_dictionary["tray_orientation_z"] = self._transform_pose_tray_1.orientation.z
                        data_dictionary["tray_orientation_w"] = self._transform_pose_tray_1.orientation.w
                        data_dictionary["tray_table"] = "kts2"
                except:
                    pass

            def __str__(self):
                """Overriding the inbuilt str function.

                Returns:
                    str: String containing the ID of the tray. 
                """
                text2 = f"\nTray: \n    -id: {self._id} \n    -pose: "
                return text2
    

        if self._iterations4:
            if message2.tray_poses != []:
                self._counter4 += 1
                if self._counter4 < 4:
                    
                    object2 = AdvancedLogicalCameraImage(message2.part_poses, message2.tray_poses[0].id, message2.tray_poses[0].pose.position.x,
                                                        message2.tray_poses[0].pose.position.y, message2.tray_poses[0].pose.position.z,
                                                        message2.tray_poses[0].pose.orientation.x, message2.tray_poses[0].pose.orientation.y,
                                                        message2.tray_poses[0].pose.orientation.z, message2.tray_poses[0].pose.orientation.w,
                                                        message2.sensor_pose.position.x, message2.sensor_pose.position.y, message2.sensor_pose.position.z,
                                                        message2.sensor_pose.orientation.x, message2.sensor_pose.orientation.y,
                                                        message2.sensor_pose.orientation.z, message2.sensor_pose.orientation.w)
                    

                    world_pose = object2._multiply_pose(object2._pose2, object2._pose1)

                    # self.get_logger().info(f"{str(object2)}\n      -position: [{world_pose.position.x}, {world_pose.position.y}, {world_pose.position.z}]\n      -orientation: [{world_pose.orientation.x}, {world_pose.orientation.y}, {world_pose.orientation.z}, {world_pose.orientation.w}]")
                    self.iterations4 = False





    def _competition_state_cb(self, msg: CompetitionState):
        """/ariac/competition _state topic callback function.

        Args:
            msg (CompetitionState): Competition_state message
        """
        self._competition_state = msg.competition_state


    def _robot_action_timer_callback(self):
        """
            Callback timer that triggers robots action.

        """
        if self._competition_state == CompetitionState.READY and not self._competition_started:
            self._start_competition()
        # exit the callback if the kit is completed
        if self._kit_completed:
            return

        # move robot home
        self._move_robot_home("floor_robot")        
        time.sleep(1)

        tray_pose = Pose()
        tray_pose.position.x = data_dictionary["tray_position_x"]
        tray_pose.position.y = data_dictionary['tray_position_y']
        tray_pose.position.z = data_dictionary['tray_position_z']
        tray_pose.orientation.x = data_dictionary['tray_orientation_x']
        tray_pose.orientation.y = data_dictionary['tray_orientation_y']
        tray_pose.orientation.z = data_dictionary['tray_orientation_z']
        tray_pose.orientation.w = data_dictionary['tray_orientation_w']

        part1_pose = Pose()
        part1_pose.position.x = data_dictionary['part1_position_x']
        part1_pose.position.y = data_dictionary['part1_position_y']
        part1_pose.position.z = data_dictionary['part1_position_z']
        part1_pose.orientation.x = data_dictionary['part1_orientation_x']
        part1_pose.orientation.y = data_dictionary['part1_orientation_y']
        part1_pose.orientation.z = data_dictionary['part1_orientation_z']
        part1_pose.orientation.w = data_dictionary['part1_orientation_w']  

        part2_pose = Pose()
        part2_pose.position.x = data_dictionary['part2_position_x']
        part2_pose.position.y = data_dictionary['part2_position_y']
        part2_pose.position.z = data_dictionary['part2_position_z']
        part2_pose.orientation.x = data_dictionary['part2_orientation_x']
        part2_pose.orientation.y = data_dictionary['part2_orientation_y']
        part2_pose.orientation.z = data_dictionary['part2_orientation_z']
        part2_pose.orientation.w = data_dictionary['part2_orientation_w']

        part1_type = data_dictionary['part1_type']
        part1_color = data_dictionary['part1_color']
        part1_quadrant = data_dictionary['part1_quadrant']
        part1_bins = data_dictionary["part1_bins"]

        if part1_type == 'battery':
            part1_type = 10
        elif part1_type == 'pump':
            part1_type = 11
        elif part1_type == 'sensor':
            part1_type = 12
        elif part1_type == 'regulator':
            part1_type = 13
            
        if part1_color == 'red':
            part1_color = 0
        elif part1_color == 'green':
            part1_color = 1
        elif part1_color == 'blue':
            part1_color = 2
        elif part1_color == 'orange':
            part1_color = 3
        elif part1_color == 'purple':
            part1_color = 4


        part2_type = data_dictionary['part2_type']
        part2_color = data_dictionary['part2_color']
        part2_quadrant = data_dictionary['part2_quadrant']
        part2_bins = data_dictionary["part2_bins"]

        location = data_dictionary['destination']
        if location == "warehouse":
            location = 3

        if part2_type == 'battery':
            part2_type = 10
        elif part2_type == 'pump':
            part2_type = 11
        elif part2_type == 'sensor':
            part2_type = 12
        elif part2_type == 'regulator':
            part2_type = 13

        if part2_color == 'red':
            part2_color = 0
        elif part2_color == 'green':
            part2_color = 1
        elif part2_color == 'blue':
            part2_color = 2
        elif part2_color == 'orange':
            part2_color = 3
        elif part2_color == 'purple':
            part2_color = 4

        tray_id = data_dictionary['tray_id']
        tray_table = data_dictionary['tray_table']

        agv_number = (data_dictionary['agv_number'])

        if agv_number == 1:
            agv = "agv1"
        elif agv_number == 2:
            agv = "agv2"
        elif agv_number == 3:
            agv = "agv3"
        elif agv_number == 4:
            agv = "agv4"
                
 
        # change gripper type

        self._goto_tool_changer("floor_robot", tray_table, "trays")
        self._retract_from_tool_changer("floor_robot", tray_table, "trays")

        self._pickup_tray("floor_robot", tray_id, tray_pose, tray_table)
        self._move_tray_to_agv("floor_robot", tray_pose, agv)
        self._place_tray("floor_robot", tray_id, agv)
        self._retract_from_agv("floor_robot", agv)

        self._goto_tool_changer("floor_robot", tray_table, "parts")
        self._retract_from_tool_changer("floor_robot", tray_table, "parts")

        self._pickup_part("floor_robot", part1_pose, part1_type, part1_color, part1_bins)
        self._move_part_to_agv("floor_robot", part1_pose, agv, part1_quadrant)
        self._place_part_in_tray("floor_robot", agv, part1_quadrant)
        self._retract_from_agv("floor_robot", agv)

        self._move_robot_home("floor_robot")

        self._pickup_part("floor_robot", part2_pose, part2_type, part2_color, part2_bins)
        self._move_part_to_agv("floor_robot", part2_pose, agv, part2_quadrant)
        self._place_part_in_tray("floor_robot", agv, part2_quadrant)
        self._retract_from_agv("floor_robot", agv)

        self._move_robot_home("floor_robot")

        self._lock_agv()
        self._move_agv_to_warehouse(location)


        # to ignore function calls in this callback
        self._kit_completed = True
        

    #1. Method defination to start the competition.
    def _start_competition(self):
        """Method for starting the competition.
        """
        self.get_logger().info('Waiting for competition state READY')

        request = Trigger.Request()
        future = self._start_competition_client.call_async(request)

        # Wait until the service call is completed
        rclpy.spin_until_future_complete(self, future)
        if future.result().success:
            self.get_logger().info('Started competition.')
            self._competition_started = True
        else:
            self.get_logger().warn('Unable to start competition')



    #2. Method defination to move the end eﬀector of the robot in one of the two tool changers at one of the two stations.
    def _goto_tool_changer(self, robot, station, gripper_type):
        """Moves the robot's end factor inside the gripper type slot.

        Args:
            station (str): Gripper Station name.
            gripper_type (str): Gripper type.

        Raises:
            KeyboardInterrupt:Exception is raised when the user presses ctrl+c
        """
        self.get_logger().info('Move inside gripper slot service called')

        request = EnterToolChanger.Request()

        if robot == "floor_robot":
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError('Invalid robot name')

        request.station = station
        request.gripper_type = gripper_type

        future = self._goto_tool_changer_client.call_async(request)

        try:
            rclpy.spin_until_future_complete(self, future)
        except KeyboardInterrupt as kb_error:
            raise KeyboardInterrupt from kb_error

        if future.result() is not None:
            self._change_gripper(gripper_type)
            response = future.result()
            if response:
                self.get_logger().info('Robot is at the tool changer')

        else:
            self.get_logger().error(f'Service call failed {future.exception()}')
            self.get_logger().error('Unable to move the robot to the tool changer')


    #3. Method defination to move the robot to home configuration.
    def _move_robot_home(self, robot_name):
        """Moving the robot at its home position.

        Args:
            robot_name (str): Name of the robot.
        """
        request = Trigger.Request()

        if robot_name == 'floor_robot':
            if not self._move_floor_robot_home_client.wait_for_service(timeout_sec=1.0):
                self.get_logger().error('Robot commander node not running')
                return

            future = self._move_floor_robot_home_client.call_async(request)
        else:
            self.get_logger().error(f'Robot name: ({robot_name}) is not valid')
            return

        # Wait until the service call is completed
        rclpy.spin_until_future_complete(self, future)

        if future.result().success:
            self.get_logger().info(f'Moved {robot_name} to home position')
        else:
            self.get_logger().warn(future.result().message)


    #4. Method defination to move the end eﬀector out of the tool changer at the speciﬁed station.
    def _retract_from_tool_changer(self, robot, station, gripper_type):
        """Retracting the robot's end faactor out of the gripper type slot.

        Args:
            robot (str_): Name of the robot.
            station (str): Gripper station name.
            gripper_type (str): Gripper type


        Raises:
            ValueError: Raises value error for invalid name.
            KeyboardInterrupt: Exception is raised when the user presses ctrl+c.
        """
        self.get_logger().info("Retract from gripper slot service called")

        request = ExitToolChanger.Request()

        if robot == "floor_robot":
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError('Invalid robot name')

        request.station = station
        request.gripper_type = gripper_type

        future = self._retract_from_tool_changer_client.call_async(request)

        try:
            rclpy.spin_until_future_complete(self, future)
        except KeyboardInterrupt as kb_error:
            raise KeyboardInterrupt from kb_error

        if future.result() is not None:
            response = future.result()
            if response:
                self.get_logger().info(f'Robot is moving away from tool changer')
        else:
            self.get_logger().error(f'Service call failed {future.exception()}')
            self.get_logger().error('Unable to move the robot from the tool changer')


    #5. Method defination to set the floor robot gripper state.
    def _set_floor_robot_gripper_state(self, enable):
        """This method enables and disables the floor robots gripper state.

        Args:
            enable (bool): If set True enables the gripper, else disables.
        """
        request = VacuumGripperControl.Request()
        request.enable = enable
        future = self._set_floor_robot_gripper_state_client.call_async(request)
        rclpy.spin_until_future_complete(self, future)
        if future.result() is not None and future.result().success:
            self.get_logger().info("Floor robot's gripper is enabled.")
            
        else:
            self.get_logger().warn("Floor robot's gripper is disabled.")


    #6. Method defination to pick up the tray.
    def _pickup_tray(self, robot, tray_id, tray_pose, tray_station):
        """Method defination enables the robot's enables the end factor to pick up the tray.

        Args:
            robot (str): Name of the robot.
            tray_id (str): Tray ID
            tray_pose (int): Position and Orientation of tray.
            tray_station (str): Name of tray station.

        Raises:
            ValueError: Raises value error for invalid name.
            KeyboardInterrupt: Exception is raised when the user presses ctrl+c.
        """
        self.get_logger().info('Pickup tray service called')

        request = PickupTray.Request()

        if robot == "floor_robot":
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError("Invalid Robot Name")
        
        request.tray_id = tray_id
        request.tray_pose = tray_pose
        request.tray_station = tray_station

        future = self._pickup_tray_client.call_async(request)

        try:
            rclpy.spin_until_future_complete(self, future)
        except KeyboardInterrupt as kb_error:
            raise KeyboardInterrupt from kb_error

        if future.result() is not None and future.result().success:
            response = future.result()
            if response:
                self._set_floor_robot_gripper_state(True)
                self.get_logger().info(f'Robot has picked up the tray')
        else:
            self.get_logger().error(f'Service call failed {future.exception()}')
            self.get_logger().error('Unable to move the robot from the tool changer')      


    # 7. Method definition to move tray to agv
    def _move_tray_to_agv(self, robot, tray_pose, agv):
        """Method defination that moves the picked up tray to the agv

        Args:
            robot (str): Name of the robot.
            tray_pose (int):Position and orientation of tray.
            agv (str): Agv number

        Raises:
            ValueError: Raises value error for invalid name.
            KeyboardInterrupt: Exception is raised when the user presses ctrl+c.
        """
        self.get_logger().info("Move tray to agv service called")
        request = MoveTrayToAGV.Request()

        if robot == "floor_robot":
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError("Invalid Robot Name")
        
        request.tray_pose = tray_pose
        request.agv = agv

        future = self._move_tray_to_agv_client.call_async(request)

        try:
            rclpy.spin_until_future_complete(self, future)
        except KeyboardInterrupt as kb_error:
            raise KeyboardInterrupt from kb_error
        
        if future.result is not None and future.result().success:
            response = future.result
            if response:
                self.get_logger().info("Moving tray to agv")
                time.sleep(2)
        else:
            self.get_logger().error(f'Service call failed {future.exception()}')
            self.get_logger().error('Unable to move the robot from the tool changer') 


    #8. Method defination to place the tray on agv.
    def _place_tray(self, robot, tray_id, agv):
        """Method defination to place the tray on the agv.

        Args:
            robot (str): Name of the robot.
            tray_id (int):Tray ID
            agv (str): Agv number.

        Raises:
            ValueError: Raises value error for invalid name.
            KeyboardInterrupt: Exception is raised when the user presses ctrl+c.
        """
        self.get_logger().info('Place tray on agv service called')

        request = PlaceTrayOnAGV.Request()

        if robot == "floor_robot":
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError("Invalid Robot Name")      

        request.tray_id = tray_id
        request.agv = agv

        future = self._place_tray_client.call_async(request)

        try:
            rclpy.spin_until_future_complete(self, future)
        except KeyboardInterrupt as kb_error:
            raise KeyboardInterrupt from kb_error

        if future.result() is not None and future.result().success:
            response = future.result()
            if response:
                self.get_logger().info("Placing tray on agv")
                self._set_floor_robot_gripper_state(False)
        else:
            self.get_logger().error(f'Service call failed {future.exception()}')
            self.get_logger().error('Unable to move the robot from the tool changer')       


    #9. Method defination retract from the AGV after placing tray on the AGV.
    def _retract_from_agv(self, robot, agv):
        """Method that retracts the robot's end factor from the agv.

        Args:
            robot (str): Robot name.
            agv (str):Agv Number.

        Raises:
            ValueError: Raises value error for invalid name.
            KeyboardInterrupt: Exception is raised when the user presses ctrl+c.
        """
        self.get_logger().info('Retract the agv service called')

        request = RetractFromAGV.Request()

        if robot == "floor_robot":
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError("Invalid Robot Name")      

        request.agv = agv

        future = self._retract_from_agv_client.call_async(request)

        try:
            rclpy.spin_until_future_complete(self, future)
        except KeyboardInterrupt as kb_error:
            raise KeyboardInterrupt from kb_error

        if future.result() is not None:
            response = future.result()
            if response:
                self.get_logger().info("Retracting the agv")

        else:
            self.get_logger().error(f'Service call failed {future.exception()}')
            self.get_logger().error('Unable to move the robot from the tool changer') 


    #10. Method defination to pickup the part from bins.
    def _pickup_part(self, robot, part_pose, part_type, part_color, bin_side):
        """Method that picks up the part from the left or right bin as per the order.

        Args:
            robot (str): Name of the robot.
            part_pose (int): Part position and orientation.
            part_type (int): Type of part.
            part_color (int): Color of the part.
            bin_side (str): left or right side 

        Raises:
            ValueError: Raises value error for invalid name.
            KeyboardInterrupt: Exception is raised when the user presses ctrl+c.
        """
        self.get_logger().info('Pick up part service called')

        request = PickupPart.Request()

        if robot == "floor_robot":
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError("Invalid Robot Name")                

        request.part_pose = part_pose
        request.part_type = part_type
        request.part_color = part_color
        request.bin_side = bin_side

        future = self._pickup_part_client.call_async(request)

        try:
            rclpy.spin_until_future_complete(self, future)
        except KeyboardInterrupt as kb_error:
            raise KeyboardInterrupt from kb_error

        if future.result() is not None:
            response = future.result()
            if response:
                self.get_logger().info("Picking up the part")
                self._set_floor_robot_gripper_state(True)

        else:
            self.get_logger().error(f'Service call failed {future.exception()}')
            self.get_logger().error('Unable to move the robot from the tool changer')         



    #11. Method defination to move the part to agv.
    def _move_part_to_agv(self, robot, part_pose, agv, quadrant):
        """Method to move the part to the agv.

        Args:
            robot (str): Name of the robot.
            part_pose (int): Position and Orientation of part
            agv (str): Agv number
            quadrant (int): quadrant at which part is placed.

        Raises:
            ValueError: Raises value error for invalid name.
            KeyboardInterrupt: Exception is raised when the user presses ctrl+c.
        """
        self.get_logger().info('Move part to agv service called')     

        request = MovePartToAGV.Request()

        if robot == "floor_robot":
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError("Invalid Robot Name")
        
        request.part_pose = part_pose
        request.agv = agv
        request.quadrant = quadrant

        future = self._move_part_to_agv_client.call_async(request)

        try:
            rclpy.spin_until_future_complete(self, future)
        except KeyboardInterrupt as kb_error:
            raise KeyboardInterrupt from kb_error

        if future.result() is not None:
            response = future.result()
            if response:
                self.get_logger().info("Moving the part to agv")

        else:
            self.get_logger().error(f'Service call failed {future.exception()}')
            self.get_logger().error('Unable to move the robot from the tool changer')       



    #12. Method defination to place the part in tray.
    def _place_part_in_tray(self, robot, agv, quadrant):
        """Method that places the part on te tray.

        Args:
            robot (str): Name of the robot.
            agv (str): Agv number.
            quadrant (int): Quadrant of part at which part would be placed.

        Raises:
            ValueError: Raises value error for invalid name.
            KeyboardInterrupt: Exception is raised when the user presses ctrl+c.
        """
        self.get_logger().info('Placing the part at the tray service called')
        request = PlacePartInTray.Request()

        if robot == "floor_robot":
            request.robot = RobotsMsg.FLOOR_ROBOT
        else:
            raise ValueError("Invalid Robot Name")
        
        request.agv = agv
        request.quadrant = quadrant

        future = self._place_part_in_tray_client.call_async(request)

        try:
            rclpy.spin_until_future_complete(self, future)
        except KeyboardInterrupt as kb_error:
            raise KeyboardInterrupt from kb_error

        if future.result() is not None:
            response = future.result()
            if response:
                self.get_logger().info("Placing the part in the tray")
                self._set_floor_robot_gripper_state(False)
        else:
            self.get_logger().error(f'Service call failed {future.exception()}')
            self.get_logger().error('Unable to move the robot from the tool changer')


    #13. Method defination to lock the tray on agv, so that parts do not fall. 
    def _lock_agv(self):
        """Method that locks the tray placed on agv.
        """
        self.get_logger().info('Locking the tray service called')
        request = Trigger.Request()
        if data_dictionary['agv_number'] == 1:
            future = self._lock_agv1_client.call_async(request)
        elif data_dictionary['agv_number'] == 2:
            future = self._lock_agv2_client.call_async(request)
        elif data_dictionary['agv_number'] == 3:
            future = self._lock_agv3_client.call_async(request)
        elif data_dictionary['agv_number'] == 4:
            future = self._lock_agv4_client.call_async(request)

        if future.result() is not None and future.result().success:
            self.get_logger().info('Tray Locked.')
            
        else:
            self.get_logger().warn('Unable to lock tray.')


    #14. Method defination to move the agv to the destination.
    def _move_agv_to_warehouse(self, location):
        """Moving the agv to the location (warehouse).

        Args:
            location (str): Location at which agv to move with parts.

        Raises:
            KeyboardInterrupt: Exception is raised when the user presses ctrl+c.
        """
        self.get_logger().info('Moving the agv at the loaction service called.')
        request = MoveAGV.Request()

        request.location = location

        if data_dictionary['agv_number'] == 1:
            future = self._move_agv1_to_warehouse_client.call_async(request)
        elif data_dictionary['agv_number'] == 2:
            future = self._move_agv2_to_warehouse_client.call_async(request)
        elif data_dictionary['agv_number'] == 3:
            future = self._move_agv3_to_warehouse_client.call_async(request)
        elif data_dictionary['agv_number'] == 4:
            future = self._move_agv4_to_warehouse_client.call_async(request)

        try:
            rclpy.spin_until_future_complete(self, future)
        except KeyboardInterrupt as kb_error:
            raise KeyboardInterrupt from kb_error

        if future.result() is not None:
            response = future.result()
            if response:
                self.get_logger().info("Moving the agv to the loaction.")
        else:
            self.get_logger().error(f'Service call failed {future.exception()}')
            self.get_logger().error('Unable to move the robot from the tool changer')


    # 15. Method definition to change gripper
    def _change_gripper(self, gripper_type):
        """Changing the gripper from the gripper slot.

        Args:
            gripper_type (str): Gripper type.

        Raises:
            KeyboardInterrupt: Exception is raised when the user presses ctrl+c.
        """
        request = ChangeGripper.Request()

        if gripper_type == "parts":
            request.gripper_type = ChangeGripper.Request.PART_GRIPPER
        elif gripper_type == 'trays':
            request.gripper_type = ChangeGripper.Request.TRAY_GRIPPER

        future = self._change_gripper_client.call_async(request)
        try:
            rclpy.spin_until_future_complete(self, future)
        except KeyboardInterrupt as kb_error:
            raise KeyboardInterrupt from kb_error
        
        if future.result() is not None:
            response = future.result()
            if response.success:
                self.get_logger().info(f'Robot gripper changed to {gripper_type}')
        else:   
            self.get_logger().warn(f'Service call failed {future.exception()}')
            self.get_logger().warn(f'Failed to change robot gripper to {gripper_type}')


def main(args=None):
    '''
    Main function to create a ROS2 node

    Args:
        args (Any, optional): ROS2 arguments. Defaults to None.
    '''
    
    rclpy.init(args=args)
    node = RWA4('rwa4')
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

    executor = MultiThreadedExecutor()
    executor.add_node(node)
    try:
        executor.spin()
    except rclpy.executors.ExternalShutdownException:
        pass

    node.destroy_node()
    rclpy.shutdown()